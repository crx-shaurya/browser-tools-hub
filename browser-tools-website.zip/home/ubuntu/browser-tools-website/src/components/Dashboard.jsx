import { motion } from 'framer-motion'
import { 
  Calculator, 
  Type, 
  Palette, 
  Image, 
  Database, 
  Zap, 
  Globe,
  TrendingUp,
  Users,
  Clock,
  Star,
  Activity
} from 'lucide-react'
import { Button } from '@/components/ui/button'

const Dashboard = () => {
  const stats = [
    { label: 'Total Tools', value: '35+', icon: Activity, color: 'from-blue-500 to-cyan-500' },
    { label: 'Categories', value: '7', icon: TrendingUp, color: 'from-purple-500 to-pink-500' },
    { label: 'Users', value: '1.2K+', icon: Users, color: 'from-green-500 to-emerald-500' },
    { label: 'Uptime', value: '99.9%', icon: Clock, color: 'from-orange-500 to-red-500' },
  ]

  const quickTools = [
    { name: 'Word Counter', category: 'Text', icon: Type, description: 'Count words and characters instantly' },
    { name: 'Color Picker', category: 'Colors', icon: Palette, description: 'Pick and convert colors easily' },
    { name: 'QR Generator', category: 'Generators', icon: Zap, description: 'Generate QR codes quickly' },
    { name: 'Image Resizer', category: 'Images', icon: Image, description: 'Resize images on the fly' },
    { name: 'JSON Formatter', category: 'Data', icon: Database, description: 'Format and validate JSON' },
    { name: 'URL Shortener', category: 'Web', icon: Globe, description: 'Create short URLs' },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        damping: 20,
        stiffness: 100
      }
    }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Welcome Section */}
      <motion.div
        variants={itemVariants}
        className="text-center py-12 relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-800 dark:via-blue-900 dark:to-purple-900"
      >
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
            rotate: [0, 5, -5, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-4 left-4 w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full opacity-20"
        />
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, -5, 5, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
          className="absolute bottom-4 right-4 w-16 h-16 bg-gradient-to-br from-green-400 to-blue-500 rounded-full opacity-20"
        />
        
        <motion.h1
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, type: "spring", damping: 15 }}
          className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent"
        >
          Welcome to Browser Tools Hub
        </motion.h1>
        
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
        >
          Your ultimate collection of browser-based tools. Everything you need, right at your fingertips.
        </motion.p>
        
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
            Get Started
          </Button>
        </motion.div>
      </motion.div>

      {/* Stats Grid */}
      <motion.div
        variants={itemVariants}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
      >
        {stats.map((stat, index) => {
          const Icon = stat.icon
          return (
            <motion.div
              key={stat.label}
              whileHover={{ 
                scale: 1.05,
                rotateY: 5,
                z: 50
              }}
              whileTap={{ scale: 0.95 }}
              className="relative group"
            >
              <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border hover:border-primary/50 transition-all duration-300 shadow-lg hover:shadow-xl">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold mb-1">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
                
                {/* Animated background effect */}
                <motion.div
                  className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}
                  initial={false}
                />
              </div>
            </motion.div>
          )
        })}
      </motion.div>

      {/* Quick Access Tools */}
      <motion.div variants={itemVariants}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-bold">Quick Access</h2>
          <Button variant="outline" className="hover:bg-primary hover:text-primary-foreground transition-colors duration-300">
            View All Tools
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quickTools.map((tool, index) => {
            const Icon = tool.icon
            return (
              <motion.div
                key={tool.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                whileHover={{ 
                  scale: 1.03,
                  rotateX: 5,
                  z: 50
                }}
                whileTap={{ scale: 0.97 }}
                className="group cursor-pointer"
              >
                <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border hover:border-primary/50 transition-all duration-300 shadow-lg hover:shadow-xl relative overflow-hidden">
                  {/* Animated background gradient */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    animate={{
                      background: [
                        "linear-gradient(45deg, rgba(59, 130, 246, 0.05), rgba(147, 51, 234, 0.05), rgba(236, 72, 153, 0.05))",
                        "linear-gradient(135deg, rgba(147, 51, 234, 0.05), rgba(236, 72, 153, 0.05), rgba(59, 130, 246, 0.05))",
                        "linear-gradient(225deg, rgba(236, 72, 153, 0.05), rgba(59, 130, 246, 0.05), rgba(147, 51, 234, 0.05))",
                      ]
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                  />
                  
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded-full">
                        {tool.category}
                      </span>
                    </div>
                    
                    <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors duration-300">
                      {tool.name}
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      {tool.description}
                    </p>
                    
                    {/* Favorite button */}
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    >
                      <Star className="w-4 h-4 text-muted-foreground hover:text-yellow-500 hover:fill-yellow-500 transition-colors duration-200" />
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>
      </motion.div>

      {/* Recent Activity */}
      <motion.div variants={itemVariants}>
        <h2 className="text-3xl font-bold mb-6">Recent Activity</h2>
        <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
          <div className="space-y-4">
            {[
              { tool: 'Word Counter', time: '2 minutes ago', action: 'Counted 1,247 words' },
              { tool: 'Color Picker', time: '15 minutes ago', action: 'Picked #3B82F6' },
              { tool: 'QR Generator', time: '1 hour ago', action: 'Generated QR for URL' },
            ].map((activity, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * index }}
                className="flex items-center justify-between py-3 border-b border-border last:border-b-0"
              >
                <div>
                  <div className="font-medium">{activity.tool}</div>
                  <div className="text-sm text-muted-foreground">{activity.action}</div>
                </div>
                <div className="text-sm text-muted-foreground">{activity.time}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

export default Dashboard

