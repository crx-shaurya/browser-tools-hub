import { useState } from 'react'
import { motion } from 'framer-motion'
import { Zap, QrCode, Key, Hash, BarChart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const Generators = () => {
  const [activeTab, setActiveTab] = useState('qr')
  const [qrText, setQrText] = useState('')
  const [password, setPassword] = useState('')
  const [passwordLength, setPasswordLength] = useState(12)
  const [includeSymbols, setIncludeSymbols] = useState(true)
  const [includeNumbers, setIncludeNumbers] = useState(true)
  const [includeUppercase, setIncludeUppercase] = useState(true)

  const tools = [
    { id: 'qr', name: 'QR Code Generator', icon: QrCode },
    { id: 'password', name: 'Password Generator', icon: Key },
    { id: 'hash', name: 'Hash Generator', icon: Hash },
    { id: 'uuid', name: 'UUID Generator', icon: BarChart },
  ]

  const generatePassword = () => {
    let charset = 'abcdefghijklmnopqrstuvwxyz'
    if (includeUppercase) charset += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    if (includeNumbers) charset += '0123456789'
    if (includeSymbols) charset += '!@#$%^&*()_+-=[]{}|;:,.<>?'

    let result = ''
    for (let i = 0; i < passwordLength; i++) {
      result += charset.charAt(Math.floor(Math.random() * charset.length))
    }
    setPassword(result)
  }

  const generateUUID = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0
      const v = c === 'x' ? r : (r & 0x3 | 0x8)
      return v.toString(16)
    })
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <motion.div variants={itemVariants}>
        <div className="flex flex-wrap gap-2 mb-6">
          {tools.map((tool) => {
            const Icon = tool.icon
            return (
              <motion.button
                key={tool.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(tool.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                  activeTab === tool.id
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-card hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{tool.name}</span>
              </motion.button>
            )
          })}
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        {activeTab === 'qr' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border"
          >
            <h3 className="text-xl font-semibold mb-4">QR Code Generator</h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">Text or URL</label>
                <Input
                  value={qrText}
                  onChange={(e) => setQrText(e.target.value)}
                  placeholder="Enter text or URL to generate QR code"
                  className="mb-4"
                />
                <Button 
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                >
                  Generate QR Code
                </Button>
              </div>
              <div className="flex items-center justify-center">
                <div className="w-48 h-48 bg-muted border-2 border-dashed border-border rounded-xl flex items-center justify-center">
                  <QrCode className="w-16 h-16 text-muted-foreground" />
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'password' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border"
          >
            <h3 className="text-xl font-semibold mb-4">Password Generator</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Password Length: {passwordLength}</label>
                <input
                  type="range"
                  min="4"
                  max="50"
                  value={passwordLength}
                  onChange={(e) => setPasswordLength(parseInt(e.target.value))}
                  className="w-full"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={includeUppercase}
                    onChange={(e) => setIncludeUppercase(e.target.checked)}
                    className="rounded"
                  />
                  <span>Uppercase Letters</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={includeNumbers}
                    onChange={(e) => setIncludeNumbers(e.target.checked)}
                    className="rounded"
                  />
                  <span>Numbers</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={includeSymbols}
                    onChange={(e) => setIncludeSymbols(e.target.checked)}
                    className="rounded"
                  />
                  <span>Symbols</span>
                </label>
              </div>
              
              <Button
                onClick={generatePassword}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
              >
                Generate Password
              </Button>
              
              {password && (
                <div className="bg-muted p-4 rounded-xl">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-lg">{password}</span>
                    <Button
                      onClick={() => navigator.clipboard.writeText(password)}
                      size="sm"
                      variant="outline"
                    >
                      Copy
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'uuid' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border"
          >
            <h3 className="text-xl font-semibold mb-4">UUID Generator</h3>
            <div className="space-y-4">
              <p className="text-muted-foreground">
                Generate universally unique identifiers (UUIDs) for your applications.
              </p>
              
              <Button
                onClick={() => {
                  const uuid = generateUUID()
                  navigator.clipboard.writeText(uuid)
                }}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                Generate & Copy UUID
              </Button>
              
              <div className="bg-muted p-4 rounded-xl">
                <div className="font-mono text-sm text-center">
                  Click the button to generate a new UUID
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  )
}

export default Generators

