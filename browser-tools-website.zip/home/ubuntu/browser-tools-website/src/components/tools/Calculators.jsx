import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Calculator, 
  Percent, 
  Calendar, 
  Ruler,
  Delete,
  Equal
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const Calculators = () => {
  const [activeTab, setActiveTab] = useState('basic')
  const [display, setDisplay] = useState('0')
  const [previousValue, setPreviousValue] = useState(null)
  const [operation, setOperation] = useState(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)

  // Unit conversion states
  const [fromUnit, setFromUnit] = useState('meters')
  const [toUnit, setToUnit] = useState('feet')
  const [unitValue, setUnitValue] = useState('')

  // Percentage calculator states
  const [percentValue, setPercentValue] = useState('')
  const [percentOf, setPercentOf] = useState('')
  const [percentResult, setPercentResult] = useState('')

  const tools = [
    { id: 'basic', name: 'Basic Calculator', icon: Calculator },
    { id: 'scientific', name: 'Scientific', icon: Calculator },
    { id: 'unit', name: 'Unit Converter', icon: Ruler },
    { id: 'percentage', name: 'Percentage', icon: Percent },
    { id: 'date', name: 'Date Calculator', icon: Calendar },
  ]

  // Basic calculator functions
  const inputNumber = (num) => {
    if (waitingForOperand) {
      setDisplay(String(num))
      setWaitingForOperand(false)
    } else {
      setDisplay(display === '0' ? String(num) : display + num)
    }
  }

  const inputOperation = (nextOperation) => {
    const inputValue = parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(inputValue)
    } else if (operation) {
      const currentValue = previousValue || 0
      const newValue = calculate(currentValue, inputValue, operation)

      setDisplay(String(newValue))
      setPreviousValue(newValue)
    }

    setWaitingForOperand(true)
    setOperation(nextOperation)
  }

  const calculate = (firstValue, secondValue, operation) => {
    switch (operation) {
      case '+':
        return firstValue + secondValue
      case '-':
        return firstValue - secondValue
      case '*':
        return firstValue * secondValue
      case '/':
        return firstValue / secondValue
      case '=':
        return secondValue
      default:
        return secondValue
    }
  }

  const performCalculation = () => {
    const inputValue = parseFloat(display)

    if (previousValue !== null && operation) {
      const newValue = calculate(previousValue, inputValue, operation)
      setDisplay(String(newValue))
      setPreviousValue(null)
      setOperation(null)
      setWaitingForOperand(true)
    }
  }

  const clearCalculator = () => {
    setDisplay('0')
    setPreviousValue(null)
    setOperation(null)
    setWaitingForOperand(false)
  }

  // Unit conversion
  const unitConversions = {
    length: {
      meters: 1,
      feet: 3.28084,
      inches: 39.3701,
      centimeters: 100,
      kilometers: 0.001,
      miles: 0.000621371
    },
    weight: {
      kilograms: 1,
      pounds: 2.20462,
      ounces: 35.274,
      grams: 1000,
      tons: 0.001
    },
    temperature: {
      celsius: (c) => c,
      fahrenheit: (c) => (c * 9/5) + 32,
      kelvin: (c) => c + 273.15
    }
  }

  const convertUnit = () => {
    if (!unitValue) return ''
    
    const value = parseFloat(unitValue)
    if (isNaN(value)) return ''

    // Simple length conversion for demo
    const conversions = {
      'meters-feet': value * 3.28084,
      'feet-meters': value / 3.28084,
      'meters-inches': value * 39.3701,
      'inches-meters': value / 39.3701,
      'kilograms-pounds': value * 2.20462,
      'pounds-kilograms': value / 2.20462,
    }

    const key = `${fromUnit}-${toUnit}`
    return conversions[key] || value
  }

  // Percentage calculations
  const calculatePercentage = () => {
    const percent = parseFloat(percentValue)
    const of = parseFloat(percentOf)
    
    if (isNaN(percent) || isNaN(of)) return
    
    const result = (percent / 100) * of
    setPercentResult(result.toString())
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        damping: 20,
        stiffness: 100
      }
    }
  }

  const buttonVariants = {
    hover: { scale: 1.05, boxShadow: "0 5px 15px rgba(0,0,0,0.2)" },
    tap: { scale: 0.95 }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Tool Tabs */}
      <motion.div variants={itemVariants}>
        <div className="flex flex-wrap gap-2 mb-6">
          {tools.map((tool) => {
            const Icon = tool.icon
            return (
              <motion.button
                key={tool.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(tool.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                  activeTab === tool.id
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-card hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{tool.name}</span>
              </motion.button>
            )
          })}
        </div>
      </motion.div>

      {/* Calculator Content */}
      <motion.div variants={itemVariants}>
        {activeTab === 'basic' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-md mx-auto"
          >
            <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
              {/* Display */}
              <motion.div
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                className="bg-background border border-border rounded-xl p-4 mb-6"
              >
                <div className="text-right text-3xl font-mono font-bold">
                  {display}
                </div>
              </motion.div>

              {/* Buttons */}
              <div className="grid grid-cols-4 gap-3">
                {/* Row 1 */}
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
                  <Button
                    onClick={clearCalculator}
                    className="w-full h-12 bg-red-500 hover:bg-red-600 text-white"
                  >
                    C
                  </Button>
                </motion.div>
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
                  <Button variant="outline" className="w-full h-12">±</Button>
                </motion.div>
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
                  <Button variant="outline" className="w-full h-12">%</Button>
                </motion.div>
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
                  <Button
                    onClick={() => inputOperation('/')}
                    className="w-full h-12 bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    ÷
                  </Button>
                </motion.div>

                {/* Row 2 */}
                {[7, 8, 9].map((num) => (
                  <motion.div key={num} variants={buttonVariants} whileHover="hover" whileTap="tap">
                    <Button
                      onClick={() => inputNumber(num)}
                      variant="outline"
                      className="w-full h-12 hover:bg-primary hover:text-primary-foreground"
                    >
                      {num}
                    </Button>
                  </motion.div>
                ))}
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
                  <Button
                    onClick={() => inputOperation('*')}
                    className="w-full h-12 bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    ×
                  </Button>
                </motion.div>

                {/* Row 3 */}
                {[4, 5, 6].map((num) => (
                  <motion.div key={num} variants={buttonVariants} whileHover="hover" whileTap="tap">
                    <Button
                      onClick={() => inputNumber(num)}
                      variant="outline"
                      className="w-full h-12 hover:bg-primary hover:text-primary-foreground"
                    >
                      {num}
                    </Button>
                  </motion.div>
                ))}
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
                  <Button
                    onClick={() => inputOperation('-')}
                    className="w-full h-12 bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    −
                  </Button>
                </motion.div>

                {/* Row 4 */}
                {[1, 2, 3].map((num) => (
                  <motion.div key={num} variants={buttonVariants} whileHover="hover" whileTap="tap">
                    <Button
                      onClick={() => inputNumber(num)}
                      variant="outline"
                      className="w-full h-12 hover:bg-primary hover:text-primary-foreground"
                    >
                      {num}
                    </Button>
                  </motion.div>
                ))}
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
                  <Button
                    onClick={() => inputOperation('+')}
                    className="w-full h-12 bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    +
                  </Button>
                </motion.div>

                {/* Row 5 */}
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap" className="col-span-2">
                  <Button
                    onClick={() => inputNumber(0)}
                    variant="outline"
                    className="w-full h-12 hover:bg-primary hover:text-primary-foreground"
                  >
                    0
                  </Button>
                </motion.div>
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
                  <Button variant="outline" className="w-full h-12">.</Button>
                </motion.div>
                <motion.div variants={buttonVariants} whileHover="hover" whileTap="tap">
                  <Button
                    onClick={performCalculation}
                    className="w-full h-12 bg-green-500 hover:bg-green-600 text-white"
                  >
                    =
                  </Button>
                </motion.div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'unit' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-2xl mx-auto"
          >
            <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
              <h3 className="text-xl font-semibold mb-6">Unit Converter</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">From</label>
                  <select
                    value={fromUnit}
                    onChange={(e) => setFromUnit(e.target.value)}
                    className="w-full p-3 bg-background border border-border rounded-xl mb-4"
                  >
                    <option value="meters">Meters</option>
                    <option value="feet">Feet</option>
                    <option value="inches">Inches</option>
                    <option value="kilograms">Kilograms</option>
                    <option value="pounds">Pounds</option>
                  </select>
                  <Input
                    type="number"
                    value={unitValue}
                    onChange={(e) => setUnitValue(e.target.value)}
                    placeholder="Enter value"
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">To</label>
                  <select
                    value={toUnit}
                    onChange={(e) => setToUnit(e.target.value)}
                    className="w-full p-3 bg-background border border-border rounded-xl mb-4"
                  >
                    <option value="feet">Feet</option>
                    <option value="meters">Meters</option>
                    <option value="inches">Inches</option>
                    <option value="pounds">Pounds</option>
                    <option value="kilograms">Kilograms</option>
                  </select>
                  <div className="w-full p-3 bg-muted border border-border rounded-xl text-lg font-mono">
                    {convertUnit() || '0'}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'percentage' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-lg mx-auto"
          >
            <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
              <h3 className="text-xl font-semibold mb-6">Percentage Calculator</h3>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={percentValue}
                    onChange={(e) => setPercentValue(e.target.value)}
                    placeholder="Percentage"
                    className="flex-1"
                  />
                  <span className="text-lg">% of</span>
                  <Input
                    type="number"
                    value={percentOf}
                    onChange={(e) => setPercentOf(e.target.value)}
                    placeholder="Number"
                    className="flex-1"
                  />
                </div>
                
                <Button
                  onClick={calculatePercentage}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                >
                  Calculate
                </Button>
                
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">Result</div>
                  <div className="text-2xl font-bold text-primary">
                    {percentResult || '0'}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  )
}

export default Calculators

