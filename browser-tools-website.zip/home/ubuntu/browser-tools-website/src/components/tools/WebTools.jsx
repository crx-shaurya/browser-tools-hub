import { useState } from 'react'
import { motion } from 'framer-motion'
import { Globe, Link, Code, FileText, Minimize } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const WebTools = () => {
  const [activeTab, setActiveTab] = useState('shortener')
  const [longUrl, setLongUrl] = useState('')
  const [shortUrl, setShortUrl] = useState('')
  const [htmlCode, setHtmlCode] = useState('')
  const [markdownText, setMarkdownText] = useState('# Hello World\n\nThis is **bold** text and this is *italic* text.\n\n- List item 1\n- List item 2\n- List item 3')

  const tools = [
    { id: 'shortener', name: 'URL Shortener', icon: Link },
    { id: 'markdown', name: 'Markdown Editor', icon: FileText },
    { id: 'html', name: 'HTML Encoder', icon: Code },
    { id: 'minify', name: 'CSS Minifier', icon: Minimize },
  ]

  const shortenUrl = () => {
    // Simple demo shortener - in real app you'd use a service
    const shortCode = Math.random().toString(36).substring(2, 8)
    setShortUrl(`https://short.ly/${shortCode}`)
  }

  const encodeHTML = () => {
    return htmlCode
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
  }

  const decodeHTML = () => {
    return htmlCode
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
  }

  // Simple markdown to HTML converter
  const markdownToHtml = (markdown) => {
    return markdown
      .replace(/^# (.*$)/gim, '<h1>$1</h1>')
      .replace(/^## (.*$)/gim, '<h2>$1</h2>')
      .replace(/^### (.*$)/gim, '<h3>$1</h3>')
      .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*)\*/gim, '<em>$1</em>')
      .replace(/^- (.*$)/gim, '<li>$1</li>')
      .replace(/(<li>.*<\/li>)/gims, '<ul>$1</ul>')
      .replace(/\n/gim, '<br>')
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <motion.div variants={itemVariants}>
        <div className="flex flex-wrap gap-2 mb-6">
          {tools.map((tool) => {
            const Icon = tool.icon
            return (
              <motion.button
                key={tool.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(tool.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                  activeTab === tool.id
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-card hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{tool.name}</span>
              </motion.button>
            )
          })}
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        {activeTab === 'shortener' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border"
          >
            <h3 className="text-xl font-semibold mb-4">URL Shortener</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Long URL</label>
                <Input
                  value={longUrl}
                  onChange={(e) => setLongUrl(e.target.value)}
                  placeholder="https://example.com/very/long/url/here"
                  className="mb-4"
                />
              </div>
              
              <Button
                onClick={shortenUrl}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
              >
                Shorten URL
              </Button>
              
              {shortUrl && (
                <div className="bg-muted p-4 rounded-xl">
                  <div className="flex items-center justify-between">
                    <span className="font-mono">{shortUrl}</span>
                    <Button
                      onClick={() => navigator.clipboard.writeText(shortUrl)}
                      size="sm"
                      variant="outline"
                    >
                      Copy
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'markdown' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
              <h3 className="text-lg font-semibold mb-4">Markdown Editor</h3>
              <textarea
                value={markdownText}
                onChange={(e) => setMarkdownText(e.target.value)}
                placeholder="Enter your markdown here..."
                className="w-full h-80 p-4 bg-background border border-border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-primary/50 font-mono text-sm"
              />
            </div>
            
            <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
              <h3 className="text-lg font-semibold mb-4">Preview</h3>
              <div 
                className="w-full h-80 p-4 bg-background border border-border rounded-xl overflow-auto prose prose-sm max-w-none"
                dangerouslySetInnerHTML={{ __html: markdownToHtml(markdownText) }}
              />
            </div>
          </motion.div>
        )}

        {activeTab === 'html' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border"
          >
            <h3 className="text-xl font-semibold mb-4">HTML Encoder/Decoder</h3>
            <div className="space-y-4">
              <textarea
                value={htmlCode}
                onChange={(e) => setHtmlCode(e.target.value)}
                placeholder="Enter HTML code here..."
                className="w-full h-40 p-4 bg-background border border-border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-primary/50 font-mono text-sm"
              />
              
              <div className="flex gap-2">
                <Button
                  onClick={() => navigator.clipboard.writeText(encodeHTML())}
                  className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                >
                  Encode & Copy
                </Button>
                <Button
                  onClick={() => navigator.clipboard.writeText(decodeHTML())}
                  className="flex-1 bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600"
                >
                  Decode & Copy
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  )
}

export default WebTools

