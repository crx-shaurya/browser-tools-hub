import { useState } from 'react'
import { motion } from 'framer-motion'
import { Database, FileText, Code, Link } from 'lucide-react'
import { Button } from '@/components/ui/button'

const DataTools = () => {
  const [activeTab, setActiveTab] = useState('json')
  const [inputData, setInputData] = useState('')
  const [outputData, setOutputData] = useState('')

  const tools = [
    { id: 'json', name: 'JSON Formatter', icon: FileText },
    { id: 'base64', name: 'Base64 Encoder', icon: Code },
    { id: 'url', name: 'URL Encoder', icon: Link },
    { id: 'csv', name: 'CSV Converter', icon: Database },
  ]

  const formatJSON = () => {
    try {
      const parsed = JSON.parse(inputData)
      setOutputData(JSON.stringify(parsed, null, 2))
    } catch (error) {
      setOutputData('Invalid JSON format')
    }
  }

  const encodeBase64 = () => {
    try {
      setOutputData(btoa(inputData))
    } catch (error) {
      setOutputData('Error encoding to Base64')
    }
  }

  const decodeBase64 = () => {
    try {
      setOutputData(atob(inputData))
    } catch (error) {
      setOutputData('Error decoding from Base64')
    }
  }

  const encodeURL = () => {
    setOutputData(encodeURIComponent(inputData))
  }

  const decodeURL = () => {
    setOutputData(decodeURIComponent(inputData))
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <motion.div variants={itemVariants}>
        <div className="flex flex-wrap gap-2 mb-6">
          {tools.map((tool) => {
            const Icon = tool.icon
            return (
              <motion.button
                key={tool.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(tool.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                  activeTab === tool.id
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-card hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{tool.name}</span>
              </motion.button>
            )
          })}
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
            <h3 className="text-lg font-semibold mb-4">Input</h3>
            <textarea
              value={inputData}
              onChange={(e) => setInputData(e.target.value)}
              placeholder="Enter your data here..."
              className="w-full h-40 p-4 bg-background border border-border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
            
            <div className="flex flex-wrap gap-2 mt-4">
              {activeTab === 'json' && (
                <Button onClick={formatJSON} className="bg-gradient-to-r from-blue-500 to-cyan-500">
                  Format JSON
                </Button>
              )}
              {activeTab === 'base64' && (
                <>
                  <Button onClick={encodeBase64} className="bg-gradient-to-r from-green-500 to-emerald-500">
                    Encode
                  </Button>
                  <Button onClick={decodeBase64} className="bg-gradient-to-r from-red-500 to-pink-500">
                    Decode
                  </Button>
                </>
              )}
              {activeTab === 'url' && (
                <>
                  <Button onClick={encodeURL} className="bg-gradient-to-r from-purple-500 to-indigo-500">
                    Encode URL
                  </Button>
                  <Button onClick={decodeURL} className="bg-gradient-to-r from-orange-500 to-red-500">
                    Decode URL
                  </Button>
                </>
              )}
            </div>
          </div>

          <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
            <h3 className="text-lg font-semibold mb-4">Output</h3>
            <textarea
              value={outputData}
              readOnly
              placeholder="Processed data will appear here..."
              className="w-full h-40 p-4 bg-muted border border-border rounded-xl resize-none font-mono text-sm"
            />
            
            <Button
              onClick={() => navigator.clipboard.writeText(outputData)}
              className="mt-4 w-full"
              variant="outline"
            >
              Copy to Clipboard
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

export default DataTools

