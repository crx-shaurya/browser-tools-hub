import { useState } from 'react'
import { motion } from 'framer-motion'
import { Image, Crop, Resize, Filter } from 'lucide-react'
import { Button } from '@/components/ui/button'

const ImageTools = () => {
  const [activeTab, setActiveTab] = useState('resize')

  const tools = [
    { id: 'resize', name: 'Image Resizer', icon: Resize },
    { id: 'crop', name: 'Image Cropper', icon: Crop },
    { id: 'filter', name: 'Image Filters', icon: Filter },
    { id: 'convert', name: 'Format Converter', icon: Image },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <motion.div variants={itemVariants}>
        <div className="flex flex-wrap gap-2 mb-6">
          {tools.map((tool) => {
            const Icon = tool.icon
            return (
              <motion.button
                key={tool.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(tool.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                  activeTab === tool.id
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-card hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{tool.name}</span>
              </motion.button>
            )
          })}
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
          <h3 className="text-xl font-semibold mb-4">Image Tools</h3>
          <p className="text-muted-foreground mb-6">
            Upload and process images with various tools including resizing, cropping, filtering, and format conversion.
          </p>
          
          <div className="border-2 border-dashed border-border rounded-xl p-12 text-center">
            <Image className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-lg font-medium mb-2">Drop your image here</p>
            <p className="text-muted-foreground mb-4">or click to browse</p>
            <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
              Choose Image
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

export default ImageTools

