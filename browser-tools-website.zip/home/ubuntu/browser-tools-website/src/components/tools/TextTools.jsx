import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Type, 
  Copy, 
  RotateCcw, 
  FileText, 
  Hash,
  AlignLeft,
  Scissors,
  Shuffle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const TextTools = () => {
  const [text, setText] = useState('')
  const [activeTab, setActiveTab] = useState('counter')

  const tools = [
    { id: 'counter', name: 'Word Counter', icon: Hash },
    { id: 'formatter', name: 'Text Formatter', icon: AlignLeft },
    { id: 'case', name: 'Case Converter', icon: Type },
    { id: 'diff', name: 'Text Diff', icon: Scissors },
    { id: 'lorem', name: 'Lorem Generator', icon: FileText },
  ]

  // Word counter logic
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0
  const charCount = text.length
  const charCountNoSpaces = text.replace(/\s/g, '').length
  const paragraphCount = text.trim() ? text.split(/\n\s*\n/).length : 0
  const readingTime = Math.ceil(wordCount / 200) // Average reading speed

  // Case conversion functions
  const convertCase = (type) => {
    switch (type) {
      case 'upper':
        return text.toUpperCase()
      case 'lower':
        return text.toLowerCase()
      case 'title':
        return text.replace(/\w\S*/g, (txt) => 
          txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
        )
      case 'camel':
        return text.replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => 
          index === 0 ? word.toLowerCase() : word.toUpperCase()
        ).replace(/\s+/g, '')
      case 'snake':
        return text.toLowerCase().replace(/\s+/g, '_')
      default:
        return text
    }
  }

  // Text formatting functions
  const formatText = (type) => {
    switch (type) {
      case 'removeSpaces':
        return text.replace(/\s+/g, ' ').trim()
      case 'removeLineBreaks':
        return text.replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim()
      case 'addLineBreaks':
        return text.replace(/\.\s+/g, '.\n')
      default:
        return text
    }
  }

  // Lorem ipsum generator
  const generateLorem = (paragraphs = 3) => {
    const lorem = [
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
      "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
      "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
      "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.",
      "Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo."
    ]
    
    let result = []
    for (let i = 0; i < paragraphs; i++) {
      result.push(lorem[Math.floor(Math.random() * lorem.length)])
    }
    return result.join('\n\n')
  }

  const copyToClipboard = (textToCopy) => {
    navigator.clipboard.writeText(textToCopy)
    // You could add a toast notification here
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        damping: 20,
        stiffness: 100
      }
    }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Tool Tabs */}
      <motion.div variants={itemVariants}>
        <div className="flex flex-wrap gap-2 mb-6">
          {tools.map((tool) => {
            const Icon = tool.icon
            return (
              <motion.button
                key={tool.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(tool.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                  activeTab === tool.id
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-card hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{tool.name}</span>
              </motion.button>
            )
          })}
        </div>
      </motion.div>

      {/* Main Text Input */}
      <motion.div variants={itemVariants}>
        <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Text Input</h3>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setText('')}
                className="hover:bg-destructive hover:text-destructive-foreground"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Clear
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(text)}
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy
              </Button>
            </div>
          </div>
          
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Enter your text here..."
            className="w-full h-40 p-4 bg-background border border-border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all duration-300"
          />
        </div>
      </motion.div>

      {/* Tool Content */}
      <motion.div variants={itemVariants}>
        {activeTab === 'counter' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="grid grid-cols-2 md:grid-cols-5 gap-4"
          >
            {[
              { label: 'Words', value: wordCount, color: 'from-blue-500 to-cyan-500' },
              { label: 'Characters', value: charCount, color: 'from-purple-500 to-pink-500' },
              { label: 'No Spaces', value: charCountNoSpaces, color: 'from-green-500 to-emerald-500' },
              { label: 'Paragraphs', value: paragraphCount, color: 'from-orange-500 to-red-500' },
              { label: 'Reading Time', value: `${readingTime}m`, color: 'from-indigo-500 to-purple-500' },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.1 * index, type: "spring" }}
                whileHover={{ scale: 1.05 }}
                className="bg-card/80 backdrop-blur-sm rounded-xl p-4 border border-border text-center"
              >
                <div className={`text-2xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        )}

        {activeTab === 'case' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { type: 'upper', label: 'UPPERCASE' },
                { type: 'lower', label: 'lowercase' },
                { type: 'title', label: 'Title Case' },
                { type: 'camel', label: 'camelCase' },
                { type: 'snake', label: 'snake_case' },
              ].map((caseType, index) => (
                <motion.div
                  key={caseType.type}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  whileHover={{ scale: 1.02 }}
                  className="bg-card/80 backdrop-blur-sm rounded-xl p-4 border border-border"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">{caseType.label}</span>
                    <Button
                      size="sm"
                      onClick={() => setText(convertCase(caseType.type))}
                      className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                    >
                      Apply
                    </Button>
                  </div>
                  <div className="text-sm text-muted-foreground bg-muted p-2 rounded-lg font-mono">
                    {convertCase(caseType.type).substring(0, 50)}
                    {convertCase(caseType.type).length > 50 && '...'}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'formatter' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { type: 'removeSpaces', label: 'Remove Extra Spaces', desc: 'Clean up multiple spaces' },
                { type: 'removeLineBreaks', label: 'Remove Line Breaks', desc: 'Convert to single line' },
                { type: 'addLineBreaks', label: 'Add Line Breaks', desc: 'Break at sentences' },
              ].map((format, index) => (
                <motion.div
                  key={format.type}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  whileHover={{ scale: 1.02 }}
                  className="bg-card/80 backdrop-blur-sm rounded-xl p-4 border border-border"
                >
                  <h4 className="font-medium mb-2">{format.label}</h4>
                  <p className="text-sm text-muted-foreground mb-4">{format.desc}</p>
                  <Button
                    onClick={() => setText(formatText(format.type))}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                  >
                    Apply
                  </Button>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'lorem' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="bg-card/80 backdrop-blur-sm rounded-xl p-6 border border-border">
              <h3 className="text-lg font-semibold mb-4">Lorem Ipsum Generator</h3>
              <div className="flex flex-wrap gap-4 mb-4">
                {[1, 2, 3, 5, 10].map((count) => (
                  <Button
                    key={count}
                    variant="outline"
                    onClick={() => setText(generateLorem(count))}
                    className="hover:bg-primary hover:text-primary-foreground"
                  >
                    {count} Paragraph{count > 1 ? 's' : ''}
                  </Button>
                ))}
              </div>
              <Button
                onClick={() => setText(generateLorem(3))}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                <Shuffle className="w-4 h-4 mr-2" />
                Generate Random Lorem
              </Button>
            </div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  )
}

export default TextTools

