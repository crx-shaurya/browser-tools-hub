import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Palette, 
  Copy, 
  Shuffle, 
  Eye,
  Pipette,
  Contrast
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const ColorTools = () => {
  const [activeTab, setActiveTab] = useState('picker')
  const [selectedColor, setSelectedColor] = useState('#3B82F6')
  const [palette, setPalette] = useState([])
  const [contrastColor1, setContrastColor1] = useState('#000000')
  const [contrastColor2, setContrastColor2] = useState('#FFFFFF')

  const tools = [
    { id: 'picker', name: 'Color Picker', icon: Pipette },
    { id: 'palette', name: 'Palette Generator', icon: Palette },
    { id: 'contrast', name: 'Contrast Checker', icon: Contrast },
    { id: 'converter', name: 'Color Converter', icon: Eye },
  ]

  // Convert hex to RGB
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null
  }

  // Convert RGB to HSL
  const rgbToHsl = (r, g, b) => {
    r /= 255
    g /= 255
    b /= 255
    const max = Math.max(r, g, b)
    const min = Math.min(r, g, b)
    let h, s, l = (max + min) / 2

    if (max === min) {
      h = s = 0
    } else {
      const d = max - min
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break
        case g: h = (b - r) / d + 2; break
        case b: h = (r - g) / d + 4; break
      }
      h /= 6
    }

    return {
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      l: Math.round(l * 100)
    }
  }

  // Generate color palette
  const generatePalette = (baseColor) => {
    const rgb = hexToRgb(baseColor)
    if (!rgb) return []

    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b)
    const colors = []

    // Generate complementary and analogous colors
    for (let i = 0; i < 8; i++) {
      const hue = (hsl.h + (i * 45)) % 360
      const saturation = Math.max(20, hsl.s + (i % 2 === 0 ? -20 : 20))
      const lightness = Math.max(10, Math.min(90, hsl.l + (i % 3 === 0 ? -30 : i % 3 === 1 ? 0 : 30)))
      
      colors.push(hslToHex(hue, saturation, lightness))
    }

    return colors
  }

  // Convert HSL to Hex
  const hslToHex = (h, s, l) => {
    l /= 100
    const a = s * Math.min(l, 1 - l) / 100
    const f = n => {
      const k = (n + h / 30) % 12
      const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1)
      return Math.round(255 * color).toString(16).padStart(2, '0')
    }
    return `#${f(0)}${f(8)}${f(4)}`
  }

  // Calculate contrast ratio
  const getContrastRatio = (color1, color2) => {
    const getLuminance = (hex) => {
      const rgb = hexToRgb(hex)
      if (!rgb) return 0
      
      const [r, g, b] = [rgb.r, rgb.g, rgb.b].map(c => {
        c = c / 255
        return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
      })
      
      return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    const lum1 = getLuminance(color1)
    const lum2 = getLuminance(color2)
    const brightest = Math.max(lum1, lum2)
    const darkest = Math.min(lum1, lum2)
    
    return (brightest + 0.05) / (darkest + 0.05)
  }

  // Copy to clipboard
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
  }

  // Generate random color
  const generateRandomColor = () => {
    const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0')
    setSelectedColor(randomColor)
  }

  useEffect(() => {
    setPalette(generatePalette(selectedColor))
  }, [selectedColor])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        damping: 20,
        stiffness: 100
      }
    }
  }

  const colorVariants = {
    hover: { scale: 1.1, rotateZ: 5 },
    tap: { scale: 0.95 }
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Tool Tabs */}
      <motion.div variants={itemVariants}>
        <div className="flex flex-wrap gap-2 mb-6">
          {tools.map((tool) => {
            const Icon = tool.icon
            return (
              <motion.button
                key={tool.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(tool.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                  activeTab === tool.id
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-card hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{tool.name}</span>
              </motion.button>
            )
          })}
        </div>
      </motion.div>

      {/* Color Picker */}
      {activeTab === 'picker' && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          variants={itemVariants}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Color Display */}
            <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
              <h3 className="text-lg font-semibold mb-4">Color Picker</h3>
              
              <motion.div
                style={{ backgroundColor: selectedColor }}
                className="w-full h-40 rounded-xl mb-4 border-4 border-white shadow-lg"
                whileHover={{ scale: 1.02 }}
                animate={{
                  boxShadow: [
                    "0 0 20px rgba(59, 130, 246, 0.3)",
                    "0 0 30px rgba(147, 51, 234, 0.3)",
                    "0 0 20px rgba(59, 130, 246, 0.3)",
                  ]
                }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Input
                    type="color"
                    value={selectedColor}
                    onChange={(e) => setSelectedColor(e.target.value)}
                    className="w-16 h-12 p-1 border-2"
                  />
                  <Input
                    type="text"
                    value={selectedColor}
                    onChange={(e) => setSelectedColor(e.target.value)}
                    className="flex-1"
                  />
                  <Button
                    onClick={() => copyToClipboard(selectedColor)}
                    size="sm"
                    variant="outline"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                
                <Button
                  onClick={generateRandomColor}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                >
                  <Shuffle className="w-4 h-4 mr-2" />
                  Random Color
                </Button>
              </div>
            </div>

            {/* Color Information */}
            <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
              <h3 className="text-lg font-semibold mb-4">Color Information</h3>
              
              {(() => {
                const rgb = hexToRgb(selectedColor)
                const hsl = rgb ? rgbToHsl(rgb.r, rgb.g, rgb.b) : null
                
                return (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-muted p-3 rounded-lg">
                        <div className="text-sm text-muted-foreground">HEX</div>
                        <div className="font-mono font-bold">{selectedColor}</div>
                      </div>
                      <div className="bg-muted p-3 rounded-lg">
                        <div className="text-sm text-muted-foreground">RGB</div>
                        <div className="font-mono font-bold">
                          {rgb ? `${rgb.r}, ${rgb.g}, ${rgb.b}` : 'Invalid'}
                        </div>
                      </div>
                      <div className="bg-muted p-3 rounded-lg">
                        <div className="text-sm text-muted-foreground">HSL</div>
                        <div className="font-mono font-bold">
                          {hsl ? `${hsl.h}°, ${hsl.s}%, ${hsl.l}%` : 'Invalid'}
                        </div>
                      </div>
                      <div className="bg-muted p-3 rounded-lg">
                        <div className="text-sm text-muted-foreground">CSS</div>
                        <div className="font-mono font-bold text-xs">
                          color: {selectedColor}
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })()}
            </div>
          </div>
        </motion.div>
      )}

      {/* Palette Generator */}
      {activeTab === 'palette' && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          variants={itemVariants}
        >
          <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">Color Palette</h3>
              <Button
                onClick={() => setPalette(generatePalette(selectedColor))}
                variant="outline"
              >
                <Shuffle className="w-4 h-4 mr-2" />
                Regenerate
              </Button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
              {palette.map((color, index) => (
                <motion.div
                  key={index}
                  variants={colorVariants}
                  whileHover="hover"
                  whileTap="tap"
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: index * 0.1, type: "spring" }}
                  className="group cursor-pointer"
                  onClick={() => copyToClipboard(color)}
                >
                  <div
                    style={{ backgroundColor: color }}
                    className="w-full h-20 rounded-xl border-2 border-white shadow-lg group-hover:shadow-xl transition-shadow duration-300"
                  />
                  <div className="text-center mt-2">
                    <div className="text-xs font-mono font-bold">{color}</div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* Contrast Checker */}
      {activeTab === 'contrast' && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          variants={itemVariants}
        >
          <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border">
            <h3 className="text-lg font-semibold mb-6">Contrast Checker</h3>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Foreground Color</label>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="color"
                      value={contrastColor1}
                      onChange={(e) => setContrastColor1(e.target.value)}
                      className="w-16 h-12 p-1"
                    />
                    <Input
                      type="text"
                      value={contrastColor1}
                      onChange={(e) => setContrastColor1(e.target.value)}
                      className="flex-1"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Background Color</label>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="color"
                      value={contrastColor2}
                      onChange={(e) => setContrastColor2(e.target.value)}
                      className="w-16 h-12 p-1"
                    />
                    <Input
                      type="text"
                      value={contrastColor2}
                      onChange={(e) => setContrastColor2(e.target.value)}
                      className="flex-1"
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <div
                  style={{
                    backgroundColor: contrastColor2,
                    color: contrastColor1
                  }}
                  className="w-full h-32 rounded-xl flex items-center justify-center text-lg font-semibold border-2 border-border"
                >
                  Sample Text
                </div>
                
                {(() => {
                  const ratio = getContrastRatio(contrastColor1, contrastColor2)
                  const aaLarge = ratio >= 3
                  const aa = ratio >= 4.5
                  const aaa = ratio >= 7
                  
                  return (
                    <div className="mt-4 space-y-2">
                      <div className="text-center">
                        <div className="text-2xl font-bold">{ratio.toFixed(2)}:1</div>
                        <div className="text-sm text-muted-foreground">Contrast Ratio</div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div className={`p-2 rounded text-center ${aa ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                          AA Normal
                        </div>
                        <div className={`p-2 rounded text-center ${aaLarge ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                          AA Large
                        </div>
                        <div className={`p-2 rounded text-center ${aaa ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                          AAA
                        </div>
                      </div>
                    </div>
                  )
                })()}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </motion.div>
  )
}

export default ColorTools

