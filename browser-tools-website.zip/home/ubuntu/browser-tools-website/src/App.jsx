import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Calculator, 
  Type, 
  Palette, 
  Image, 
  Database, 
  Zap, 
  Globe, 
  Menu, 
  X, 
  Search,
  Moon,
  Sun,
  Heart,
  Settings,
  Home,
  Terminal,
  Shield,
  Lock,
  Cpu,
  Code,
  Wifi
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import './App.css'

// Matrix Rain Effect
const MatrixRain = () => {
  const [drops, setDrops] = useState([])

  useEffect(() => {
    const characters = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン'
    const newDrops = []
    
    for (let i = 0; i < 50; i++) {
      newDrops.push({
        id: i,
        x: Math.random() * 100,
        delay: Math.random() * 5,
        chars: Array.from({ length: 20 }, () => 
          characters[Math.floor(Math.random() * characters.length)]
        )
      })
    }
    setDrops(newDrops)
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-10">
      {drops.map((drop) => (
        <motion.div
          key={drop.id}
          className="absolute text-green-400 font-mono text-sm"
          style={{ left: `${drop.x}%` }}
          animate={{
            y: ['0vh', '100vh'],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            delay: drop.delay,
            ease: 'linear'
          }}
        >
          {drop.chars.map((char, index) => (
            <motion.div
              key={index}
              className="block"
              animate={{
                opacity: [1, 0.3, 1],
              }}
              transition={{
                duration: 0.5,
                repeat: Infinity,
                delay: index * 0.1,
              }}
            >
              {char}
            </motion.div>
          ))}
        </motion.div>
      ))}
    </div>
  )
}

// Glitch Text Effect
const GlitchText = ({ children, className = "" }) => {
  return (
    <motion.div
      className={`relative ${className}`}
      animate={{
        textShadow: [
          '0 0 0 transparent',
          '2px 0 0 #ff0000, -2px 0 0 #00ff00',
          '0 0 0 transparent',
        ]
      }}
      transition={{
        duration: 0.1,
        repeat: Infinity,
        repeatDelay: 3,
      }}
    >
      {children}
    </motion.div>
  )
}

// Terminal-style Dashboard
const HackerDashboard = () => {
  const [terminalText, setTerminalText] = useState('')
  const fullText = 'root@hacktools:~$ Welcome to the ultimate hacker toolkit...'

  useEffect(() => {
    let index = 0
    const timer = setInterval(() => {
      if (index < fullText.length) {
        setTerminalText(fullText.slice(0, index + 1))
        index++
      } else {
        clearInterval(timer)
      }
    }, 50)

    return () => clearInterval(timer)
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      {/* Terminal Welcome */}
      <div className="relative overflow-hidden rounded-lg bg-black border border-green-500 shadow-lg shadow-green-500/20">
        <div className="bg-gray-900 px-4 py-2 border-b border-green-500 flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
          <span className="text-green-400 font-mono text-sm ml-4">HACKTOOLS v2.0.1</span>
        </div>
        <div className="p-6">
          <motion.div
            className="font-mono text-green-400 text-lg mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            {terminalText}
            <motion.span
              animate={{ opacity: [1, 0] }}
              transition={{ duration: 0.8, repeat: Infinity }}
              className="text-green-500"
            >
              █
            </motion.span>
          </motion.div>
          
          <GlitchText className="text-4xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-cyan-400 to-green-400">
            BROWSER EXPLOIT TOOLKIT
          </GlitchText>
          
          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 1 }}
            className="text-green-300 mb-6 font-mono"
          >
            [CLASSIFIED] Advanced browser-based penetration testing suite
          </motion.p>
          
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="flex space-x-4"
          >
            <Button className="bg-green-600 hover:bg-green-700 text-black font-mono font-bold border border-green-400 shadow-lg shadow-green-500/30">
              <Terminal className="w-4 h-4 mr-2" />
              INITIALIZE
            </Button>
            <Button variant="outline" className="border-green-500 text-green-400 hover:bg-green-500 hover:text-black font-mono">
              <Shield className="w-4 h-4 mr-2" />
              SECURE MODE
            </Button>
          </motion.div>
        </div>
      </div>

      {/* System Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'ACTIVE EXPLOITS', value: '35+', icon: Zap, status: 'ONLINE' },
          { label: 'MODULES LOADED', value: '7', icon: Cpu, status: 'READY' },
          { label: 'SECURITY LEVEL', value: 'MAX', icon: Lock, status: 'SECURE' },
          { label: 'CONNECTION', value: 'TOR', icon: Wifi, status: 'ENCRYPTED' },
        ].map((stat, index) => {
          const Icon = stat.icon
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 * index }}
              whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(34, 197, 94, 0.3)' }}
              className="bg-black border border-green-500 rounded-lg p-4 relative overflow-hidden"
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-green-500/10 to-transparent"
                animate={{
                  x: ['-100%', '100%'],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 3,
                }}
              />
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-2">
                  <Icon className="w-6 h-6 text-green-400" />
                  <span className="text-xs font-mono text-green-500 bg-green-500/20 px-2 py-1 rounded">
                    {stat.status}
                  </span>
                </div>
                <div className="text-2xl font-bold text-green-400 font-mono">{stat.value}</div>
                <div className="text-xs text-green-300 font-mono">{stat.label}</div>
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Hacker Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          { name: 'TEXT EXPLOITS', icon: Type, desc: 'String manipulation & encoding', threat: 'LOW' },
          { name: 'CRYPTO CALC', icon: Calculator, desc: 'Cryptographic calculations', threat: 'MED' },
          { name: 'COLOR FORGE', icon: Palette, desc: 'Visual steganography tools', threat: 'LOW' },
          { name: 'IMG FORENSICS', icon: Image, desc: 'Image analysis & metadata', threat: 'HIGH' },
          { name: 'DATA BREACH', icon: Database, desc: 'Database penetration suite', threat: 'CRITICAL' },
          { name: 'PAYLOAD GEN', icon: Zap, desc: 'Exploit payload generator', threat: 'CRITICAL' },
        ].map((tool, index) => {
          const Icon = tool.icon
          const threatColors = {
            'LOW': 'text-green-400 border-green-500',
            'MED': 'text-yellow-400 border-yellow-500',
            'HIGH': 'text-orange-400 border-orange-500',
            'CRITICAL': 'text-red-400 border-red-500'
          }
          
          return (
            <motion.div
              key={tool.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * index }}
              whileHover={{ 
                scale: 1.05,
                boxShadow: '0 0 30px rgba(34, 197, 94, 0.3)',
                borderColor: '#22c55e'
              }}
              className="bg-black border border-gray-700 rounded-lg p-6 relative overflow-hidden cursor-pointer group"
            >
              {/* Scanning line effect */}
              <motion.div
                className="absolute top-0 left-0 w-full h-0.5 bg-green-400"
                animate={{
                  scaleX: [0, 1, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 3,
                }}
              />
              
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-lg bg-green-500/20 border border-green-500 flex items-center justify-center group-hover:bg-green-500/30 transition-colors">
                  <Icon className="w-6 h-6 text-green-400" />
                </div>
                <span className={`text-xs font-mono px-2 py-1 rounded border ${threatColors[tool.threat]}`}>
                  {tool.threat}
                </span>
              </div>
              
              <h3 className="text-lg font-bold text-green-400 font-mono mb-2">{tool.name}</h3>
              <p className="text-green-300 text-sm font-mono opacity-80">{tool.desc}</p>
              
              {/* Glitch effect on hover */}
              <motion.div
                className="absolute inset-0 bg-green-500/5 opacity-0 group-hover:opacity-100"
                animate={{
                  background: [
                    'rgba(34, 197, 94, 0.05)',
                    'rgba(34, 197, 94, 0.1)',
                    'rgba(34, 197, 94, 0.05)',
                  ]
                }}
                transition={{
                  duration: 0.2,
                  repeat: Infinity,
                }}
              />
            </motion.div>
          )
        })}
      </div>

      {/* System Logs */}
      <div className="bg-black border border-green-500 rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-green-400 font-mono font-bold">SYSTEM LOGS</h3>
          <div className="flex items-center space-x-2">
            <motion.div
              className="w-2 h-2 rounded-full bg-green-400"
              animate={{ opacity: [1, 0.3, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <span className="text-green-400 font-mono text-sm">LIVE</span>
          </div>
        </div>
        <div className="space-y-1 font-mono text-sm">
          {[
            '[12:34:56] INFO: Toolkit initialized successfully',
            '[12:34:57] WARN: Stealth mode activated',
            '[12:34:58] INFO: All modules loaded and ready',
            '[12:34:59] SUCCESS: Connection established via TOR',
          ].map((log, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 2 + (index * 0.5) }}
              className="text-green-300"
            >
              {log}
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  )
}

// Floating Cyber Particles
const CyberParticles = () => {
  const particles = Array.from({ length: 30 }, (_, i) => i)
  
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {particles.map((particle) => (
        <motion.div
          key={particle}
          className="absolute"
          animate={{
            x: [0, Math.random() * 200 - 100, 0],
            y: [0, Math.random() * 200 - 100, 0],
            rotate: [0, 360],
          }}
          transition={{
            duration: Math.random() * 20 + 10,
            repeat: Infinity,
            ease: "linear"
          }}
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
        >
          <div className="w-1 h-1 bg-green-400 rounded-full opacity-30" />
          <motion.div
            className="w-8 h-0.5 bg-gradient-to-r from-green-400 to-transparent absolute top-0 left-0"
            animate={{
              scaleX: [0, 1, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        </motion.div>
      ))}
    </div>
  )
}

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [darkMode, setDarkMode] = useState(true) // Default to dark for hacker theme

  const toolCategories = [
    { id: 'dashboard', name: 'Command Center', icon: Terminal },
    { id: 'text', name: 'Text Exploits', icon: Type },
    { id: 'calculators', name: 'Crypto Calc', icon: Calculator },
    { id: 'colors', name: 'Color Forge', icon: Palette },
    { id: 'images', name: 'IMG Forensics', icon: Image },
    { id: 'data', name: 'Data Breach', icon: Database },
    { id: 'generators', name: 'Payload Gen', icon: Zap },
    { id: 'web', name: 'Web Exploits', icon: Globe },
  ]

  return (
    <div className="min-h-screen bg-black text-green-400 relative overflow-hidden">
      {/* Animated Cyber Background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-black" />
        <motion.div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(90deg, transparent 98%, rgba(34, 197, 94, 0.1) 100%),
              linear-gradient(0deg, transparent 98%, rgba(34, 197, 94, 0.1) 100%)
            `,
            backgroundSize: '50px 50px'
          }}
          animate={{
            backgroundPosition: ['0px 0px', '50px 50px'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'linear'
          }}
        />
      </div>
      
      <MatrixRain />
      <CyberParticles />
      
      {/* Sidebar */}
      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: sidebarOpen ? 0 : -300 }}
        transition={{ type: "spring", damping: 25, stiffness: 200 }}
        className="fixed left-0 top-0 h-full w-80 bg-black/90 backdrop-blur-xl border-r border-green-500 z-50 lg:translate-x-0 lg:static lg:z-auto"
      >
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring" }}
              className="flex items-center space-x-3"
            >
              <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center relative">
                <Terminal className="w-6 h-6 text-black" />
                <motion.div
                  className="absolute inset-0 border border-green-400 rounded-lg"
                  animate={{
                    boxShadow: [
                      '0 0 0 0 rgba(34, 197, 94, 0.4)',
                      '0 0 0 4px rgba(34, 197, 94, 0)',
                    ]
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                  }}
                />
              </div>
              <div>
                <GlitchText className="text-xl font-bold text-green-400 font-mono">
                  HACKTOOLS
                </GlitchText>
                <p className="text-sm text-green-300 font-mono">v2.0.1-CLASSIFIED</p>
              </div>
            </motion.div>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden text-green-400 hover:text-green-300 hover:bg-green-500/20"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Navigation */}
          <nav className="space-y-2">
            {toolCategories.map((category, index) => {
              const Icon = category.icon
              
              return (
                <motion.button
                  key={category.id}
                  initial={{ x: -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.1 * index }}
                  whileHover={{ 
                    scale: 1.02, 
                    x: 5,
                    boxShadow: '0 0 15px rgba(34, 197, 94, 0.3)'
                  }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-green-500/20 border border-transparent hover:border-green-500/50 font-mono"
                >
                  <Icon className="w-5 h-5 text-green-400" />
                  <span className="font-medium text-green-300">{category.name}</span>
                  <motion.div
                    className="ml-auto w-2 h-2 bg-green-400 rounded-full opacity-0"
                    whileHover={{ opacity: 1 }}
                  />
                </motion.button>
              )
            })}
          </nav>

          {/* System Status */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-8 pt-6 border-t border-green-500/30"
          >
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 mb-4">
              <div className="flex items-center justify-between">
                <span className="text-green-400 font-mono text-sm">STATUS</span>
                <motion.div
                  className="flex items-center space-x-1"
                  animate={{ opacity: [1, 0.5, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <div className="w-2 h-2 bg-green-400 rounded-full" />
                  <span className="text-green-400 font-mono text-xs">SECURE</span>
                </motion.div>
              </div>
            </div>
            
            <Button
              variant="outline"
              onClick={() => setDarkMode(!darkMode)}
              className="w-full justify-start space-x-3 border-green-500/50 text-green-400 hover:bg-green-500/20 font-mono"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              <span>{darkMode ? 'Light Mode' : 'Stealth Mode'}</span>
            </Button>
          </motion.div>
        </div>
      </motion.aside>

      {/* Main content */}
      <div className="lg:ml-80">
        {/* Top bar */}
        <motion.header
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="sticky top-0 z-30 bg-black/90 backdrop-blur-xl border-b border-green-500 p-4"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden text-green-400 hover:text-green-300 hover:bg-green-500/20"
              >
                <Menu className="w-5 h-5" />
              </Button>
              
              <GlitchText className="text-2xl font-bold font-mono text-green-400">
                COMMAND CENTER
              </GlitchText>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" className="text-green-400 hover:text-green-300 hover:bg-green-500/20">
                <Shield className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-green-400 hover:text-green-300 hover:bg-green-500/20">
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </motion.header>

        {/* Tool content */}
        <main className="p-6">
          <HackerDashboard />
        </main>
      </div>
    </div>
  )
}

export default App

